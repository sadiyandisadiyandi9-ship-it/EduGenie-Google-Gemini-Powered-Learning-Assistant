# Gemini Learn

A responsive Gemini-powered learning assistant starter with Explain, Quiz, Summarize, Study Plan, Project Report modes and date-grouped browser history.

## Run locally
1. Install Node.js 20 or newer.
2. Extract the ZIP and open this folder in VS Code.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Add your Gemini API key from Google AI Studio to `.env.local`.
6. Run `npm run dev` and open http://localhost:3000.

## Important
- API key is read server-side only.
- Learning history is saved in this browser's localStorage for this starter. It is not yet synced across devices or accounts.
- For a real multi-user deployment, add Supabase Auth, PostgreSQL tables, row-level security, and server-side history persistence.
- Do not commit `.env.local`.

## Project structure
src/app/page.tsx                 Dashboard, learning modes, date-grouped history
src/app/api/learn/route.ts       Secure server-side Gemini endpoint
src/app/layout.tsx               App metadata and root layout
src/app/globals.css              Responsive glassmorphism design
