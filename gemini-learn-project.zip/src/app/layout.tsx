import "./globals.css";
export const metadata={title:"Gemini Learn | AI Learning Companion",description:"Learn, quiz, revise, and track your progress with Gemini AI."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}