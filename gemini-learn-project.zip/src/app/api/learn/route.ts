import {NextResponse} from "next/server";
import {GoogleGenerativeAI} from "@google/generative-ai";
export async function POST(req:Request){
 try{
  const {topic,prompt,mode}=await req.json();
  if(!topic||!prompt||!mode)return NextResponse.json({error:"Please provide a topic, mode, and prompt."},{status:400});
  if(!process.env.GEMINI_API_KEY)return NextResponse.json({error:"Gemini API key is missing. Copy .env.example to .env.local, add your Google AI Studio key, then restart the server."},{status:503});
  const genAI=new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  const model=genAI.getGenerativeModel({model:process.env.GEMINI_MODEL||"gemini-2.5-flash"});
  const result=await model.generateContent(`You are a supportive academic learning assistant. Mode: ${mode}. Subject: ${topic}. User request: ${prompt}. Be accurate, structured, student-friendly, and use headings and examples where helpful. For quizzes include answer key and explanations. For study plans provide actionable daily steps. For reports clearly mark sections.`);
  return NextResponse.json({answer:result.response.text()});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"AI request failed."},{status:500})}
}